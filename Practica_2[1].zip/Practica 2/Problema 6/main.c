#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float X=0,FX;
	
	printf("Este programa presenta los valores de la funcion seno(2x)-x\npara 0,0.5, 1.0,�, 9.5, 10.");
	for(X=0;X<=10;X+=0.5){
		FX=sin(2*X)-X;
		printf("\n\nF(%.1f)=sin(2*(%.1f))-(%.1f) = %.4f",X,X,X,FX);	
	}
	system("pause");
	return 0;
}
