#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    float num1,num2,resultado;
    char oper;
    
    printf("\nEste programa hace operaciones solo entre dos numeros");
    printf("\nSi desea salir escriba S en el operador");
    
    Inicio2:
    printf("\n\nIngrese el primer numero: ");
    scanf("%f",&num1);
    printf("\nIngrese el segundo numero: ");
    scanf("%f",&num2);
    
    Inicio:
    printf("\nIngrese el operador: ");
    scanf("%C",&oper);
    scanf("%C",&oper);
    switch(oper){
         case '+': resultado=num1+num2; 
		 			 break;
         case '-': resultado=num1-num2; 
					 break;
         case '*': resultado=num1*num2; 
					 break;
         case '/': resultado=num1/num2; 
		 			 break; 
		 case 's':  
		 case 'S': goto Salir;
		 			 break;  
		 default: printf("No ingreso un operador\n");  
		 		  goto Inicio;             
    }
    
    printf("\nResultado= %.2f\n\n",resultado);
    goto Inicio2;
    Salir:
  system("exit");	
  return 0;
}
