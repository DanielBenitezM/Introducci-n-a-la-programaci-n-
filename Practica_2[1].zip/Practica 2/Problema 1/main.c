#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[])
{
  float X,fX;
  printf("Este programa clacula f(x)\nA continuacion ingrese X: ");
  scanf("%f",&X);
  
  if(X<=0){
       fX=pow(X,2)-X;
       printf("El resultado de f(x) valuada en %.2f es %.2f\n\n",X,fX);
  }
  else{
      fX=(-1)*pow(X,2)+3*X;
      printf("El resultado de f(x) valuada en %.2f es %.2f\n\n",X,fX);  
  }
  system("PAUSE");	
  return 0;
}
