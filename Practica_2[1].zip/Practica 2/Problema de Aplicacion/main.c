#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int opcion,porcent,i;
	
	printf("\t\tControl de humedad en invernadero");
	printf("\n\nQue esta usted cosechando en este momento? Escriba el numero de opcion:\n\n");
	printf("\t\t1- Solo tomate\n");
	printf("\t\t2- Solo melon\n");
	printf("\t\t3- Solo pepino\n");
	printf("\t\t4- Solo calabacita\n");
	printf("\t\t5- Tomate con calabacita\n");
	printf("\t\t6- Melon con calabacita\n");
	printf("\t\t7- Pepino con calabacita");
	Inicio1:
	printf("\nOpcion No: "); scanf("%i",&opcion);
	
	switch(opcion){
		case 1: system("cls");
				printf("\t\tControl de humedad en invernadero para tomate\n\n");
				printf("Que porcentaje de humedad indica el sensor ahora mismo?\n\t\t\t\t"); scanf("%i",&porcent);
				if(porcent<50){
					while(porcent<=50){
						for(i=1;i<=3;i++){
							system("cls");
							printf("\t\tControl de humedad en invernadero para tomate\n\n");
							printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
							printf("\n\n\t\t\tLa humedad es muy baja! ");
							printf("\n\n\t\t\tRegando invernadero... %i seg",i);
							sleep(1000);
						}
					porcent+=4;
					}
					system("cls");
					printf("\t\tControl de humedad en invernadero para tomate\n\n");
					printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
					printf("\n\n\t\t\tLa humedad es optima para los tomates\n\n");	
				}
				else{
					if(porcent>60){
							while(porcent>=60){
								for(i=1;i<=5;i++){
									system("cls");
									printf("\t\tControl de humedad en invernadero para tomate\n\n");
									printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
									printf("\n\n\t\t\tLa humedad es muy alta! ");
									printf("\n\n\t\t\tAbriendo ventanillas... %i seg",i);
									sleep(1000);
								}
								porcent-=3;
							}
						system("cls");
						printf("\t\tControl de humedad en invernadero para tomate\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\t\tLa humedad es optima para los tomates\n\n");	
					}
					else{
						system("cls");
						printf("\t\tControl de humedad en invernadero para tomate\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\t\tLa humedad es optima para los tomates\n\n");
					}
				}
		break;
				
		case 2: system("cls");
				printf("\t\tControl de humedad en invernadero para melon\n\n");
				printf("Que porcentaje de humedad indica el sensor ahora mismo?\n\t\t\t\t"); scanf("%i",&porcent);
				if(porcent<60){
					while(porcent<=60){
						for(i=1;i<=3;i++){
							system("cls");
							printf("\t\tControl de humedad en invernadero para melon\n\n");
							printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
							printf("\n\n\t\t\tLa humedad es muy baja! ");
							printf("\n\n\t\t\tRegando invernadero... %i seg",i);
							sleep(1000);
						}
					porcent+=4;
					}
					system("cls");
					printf("\t\tControl de humedad en invernadero para melon\n\n");
					printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
					printf("\n\n\t\tLa humedad es optima para la siembra de melon\n\n");	
				}
				else{
					if(porcent>70){
							while(porcent>=70){
								for(i=1;i<=5;i++){
									system("cls");
									printf("\t\tControl de humedad en invernadero para melon\n\n");
									printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
									printf("\n\n\t\t\tLa humedad es muy alta! ");
									printf("\n\n\t\t\tAbriendo ventanillas... %i seg",i);
									sleep(1000);
								}
								porcent-=3;
							}
						system("cls");
						printf("\t\tControl de humedad en invernadero para melon\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para la siembra de melon\n\n");	
					}
					else{
						system("cls");
						printf("\t\tControl de humedad en invernadero para melon\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para la siembra de melon\n\n");
					}
				}
		break;
				
		case 3: system("cls");
				printf("\t\tControl de humedad en invernadero para pepino\n\n");
				printf("Que porcentaje de humedad indica el sensor ahora mismo?\n\t\t\t\t"); scanf("%i",&porcent);
				if(porcent<70){
					while(porcent<=70){
						for(i=1;i<=3;i++){
							system("cls");
							printf("\t\tControl de humedad en invernadero para pepino\n\n");
							printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
							printf("\n\n\t\t\tLa humedad es muy baja! ");
							printf("\n\n\t\t\tRegando invernadero... %i seg",i);
							sleep(1000);
						}
					porcent+=4;
					}
					system("cls");
					printf("\t\tControl de humedad en invernadero para pepino\n\n");
					printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
					printf("\n\n\t\tLa humedad es optima para la siembra de pepino\n\n");	
				}
				else{
					if(porcent>90){
							while(porcent>=90){
								for(i=1;i<=5;i++){
									system("cls");
									printf("\t\tControl de humedad en invernadero para pepino\n\n");
									printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
									printf("\n\n\t\t\tLa humedad es muy alta! ");
									printf("\n\n\t\t\tAbriendo ventanillas... %i seg",i);
									sleep(1000);
								}
								porcent-=3;
								}
						system("cls");
						printf("\t\tControl de humedad en invernadero para pepino\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para la siembra de pepino\n\n");	
					}
					else{
						system("cls");
						printf("\t\tControl de humedad en invernadero para pepino\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para la siembra de pepino\n\n");
					}
				}
				break;
				
		case 4: system("cls");
				printf("\t\tControl de humedad en invernadero para calabacita\n\n");
				printf("Que porcentaje de humedad indica el sensor ahora mismo?\n\t\t\t\t"); scanf("%i",&porcent);
				if(porcent<55){
					while(porcent<55){
						for(i=1;i<=3;i++){
							system("cls");
							printf("\t\tControl de humedad en invernadero para calabacita\n\n");
							printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
							printf("\n\n\t\t\tLa humedad es muy baja! ");
							printf("\n\n\t\t\tRegando invernadero... %i seg",i);
							sleep(1000);
						}
					porcent+=4;
					}
					system("cls");
					printf("\t\tControl de humedad en invernadero para calabacita\n\n");
					printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
					printf("\n\n\t\tLa humedad es optima para la siembra de calabacita\n\n");	
				}
				else{
					if(porcent>80){
							while(porcent>=80){
								for(i=1;i<=5;i++){
									system("cls");
									printf("\t\tControl de humedad en invernadero para calabacita\n\n");
									printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
									printf("\n\n\t\t\tLa humedad es muy alta! ");
									printf("\n\n\t\t\tAbriendo ventanillas... %i seg",i);
									sleep(1000);
								}
								porcent-=3;
								}
						system("cls");
						printf("\t\tControl de humedad en invernadero para calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para la siembra de calabacita\n\n");	
					}
					else{
						system("cls");
						printf("\t\tControl de humedad en invernadero para calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para la siembra de calabacita\n\n");
					}
				}
				break;
				
		case 5: system("cls");
				printf("\tControl de humedad en invernadero para tomate y calabacita\n\n");
				printf("Que porcentaje de humedad indica el sensor ahora mismo?\n\t\t\t\t"); scanf("%i",&porcent);
				if(porcent<55){
					while(porcent<=55){
						for(i=1;i<=3;i++){
							system("cls");
							printf("\tControl de humedad en invernadero para tomate y calabacita\n\n");
							printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
							printf("\n\n\t\t\tLa humedad es muy baja! ");
							printf("\n\n\t\t\tRegando invernadero... %i seg",i);
							sleep(1000);
						}
					porcent+=4;
					}
					system("cls");
					printf("\tControl de humedad en invernadero para tomate y calabacita\n\n");
					printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
					printf("\n\n\t\tLa humedad es optima para los tomates y la calabacita\n\n");	
				}
				else{
					if(porcent>60){
							while(porcent>=60){
								for(i=1;i<=5;i++){
									system("cls");
									printf("\tControl de humedad en invernadero para tomate y calabacita\n\n");
									printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
									printf("\n\n\t\t\tLa humedad es muy alta! ");
									printf("\n\n\t\t\tAbriendo ventanillas... %i seg",i);
									sleep(1000);
								}
								porcent-=3;
								}
						system("cls");
						printf("\t\tControl de humedad en invernadero para tomate y calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para los tomates y la calabacita\n\n");	
					}
					else{
						system("cls");
						printf("\t\tControl de humedad en invernadero para tomate y calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para los tomates y la calabacita\n\n");
					}
				}
				break;
				
		case 6: system("cls");
				printf("\tControl de humedad en invernadero para melon y calabacita\n\n");
				printf("Que porcentaje de humedad indica el sensor ahora mismo?\n\t\t\t\t"); scanf("%i",&porcent);
				if(porcent<60){
					while(porcent<=60){
						for(i=1;i<=3;i++){
							system("cls");
							printf("\t\tControl de humedad en invernadero para melon y calabacita\n\n");
							printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
							printf("\n\n\t\t\tLa humedad es muy baja! ");
							printf("\n\n\t\t\tRegando invernadero... %i seg",i);
							sleep(1000);
						}
					porcent+=4;
					}
					system("cls");
					printf("\t\tControl de humedad en invernadero para melon y calabacita\n\n");
					printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
					printf("\n\n\t\tLa humedad es optima para el melon y la calabacita\n\n");	
				}
				else{
					if(porcent>70){
							while(porcent>=70){
								for(i=1;i<=5;i++){
									system("cls");
									printf("\t\tControl de humedad en invernadero para melon y calabacita\n\n");
									printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
									printf("\n\n\t\t\tLa humedad es muy alta! ");
									printf("\n\n\t\t\tAbriendo ventanillas... %i seg",i);
									sleep(1000);
								}
								porcent-=3;
								}
						system("cls");
						printf("\t\tControl de humedad en invernadero para melon y calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para el melon y la calabacita\n\n");	
					}
					else{
						system("cls");
						printf("\t\tControl de humedad en invernadero para melon y calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para el melon y la calabacita\n\n");
					}
				}
				break;
				
		case 7: system("cls");
				printf("\tControl de humedad en invernadero para pepino y calabacita\n\n");
				printf("Que porcentaje de humedad indica el sensor ahora mismo?\n\t\t\t\t"); scanf("%i",&porcent);
				if(porcent<70){
					while(porcent<=70){
						for(i=1;i<=3;i++){
							system("cls");
							printf("\t\tControl de humedad en invernadero para pepino y calabacita\n\n");
							printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
							printf("\n\n\t\t\tLa humedad es muy baja! ");
							printf("\n\n\t\t\tRegando invernadero... %i seg",i);
							sleep(1000);
						}
					porcent+=4;
					}
					system("cls");
					printf("\t\tControl de humedad en invernadero para pepino y calabacita\n\n");
					printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
					printf("\n\n\t\tLa humedad es optima para el pepino y la calabacita\n\n");	
				}
				else{
					if(porcent>80){
							while(porcent>=80){
								for(i=1;i<=5;i++){
									system("cls");
									printf("\t\tControl de humedad en invernadero para pepino y calabacita\n\n");
									printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
									printf("\n\n\t\t\tLa humedad es muy alta! ");
									printf("\n\n\t\t\tAbriendo ventanillas... %i seg",i);
									sleep(1000);
								}
								porcent-=3;
								}
						system("cls");
						printf("\t\tControl de humedad en invernadero para pepino y calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para el pepino y la calabacita\n\n");	
					}
					else{
						system("cls");
						printf("\t\tControl de humedad en invernadero para pepino y calabacita\n\n");
						printf("\t\t\tHumedad relativa HR= %i por ciento",porcent);
						printf("\n\n\t\tLa humedad es optima para el pepino y la calabacita\n\n");
					}
				}
				break;
				
		default:printf("No selecciono una opcion. Intentelo de nuevo...");
				goto Inicio1;
	}
	
	
	system("pause");
	return 0;
}
