#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int i;
  float calif[10],promedio=0;
  printf("Este programa calcula el promedio de 5 calificaciones y dice si el alumno aprobo o no\n\n");
  for(i=1;i<=5;i++){
    printf("Ingrese la calificacion numero %i: ",i);
    scanf("%f",calif + i);
    promedio += (calif[i])/5;
  }
  if(promedio>=6){
     printf("\nEl alumno esta aprobado con un promedio de %.2f\n\n",promedio);              
  }
  else{
     printf("\nEl alumno esta reprobado con un promedio de %.2f\n\n",promedio);
  }
  
  
  system("PAUSE");	
  return 0;
}
