#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
   int suma=0,opcion,num;
    
  printf("\n\n1. Hamburguesa chica con papas y refresco     $20\n");
  printf("2. Hotdog y refresco                          $18\n");
  printf("3. Ensalada Rusa                              $15\n\n");
  //printf("Cantidad     Producto                                Total\n");
  inicio:
  printf("\n\nSeleccione una opcion: ");
  scanf("%i",&opcion);
  printf("Que cantidad desea comprar? ");
  scanf("%i",&num);
  
  switch(opcion){
		
		case 1: 
             printf("\nCantidad                      Producto                    Total\n");
             suma += num*20;
             printf("%i                Hamburguesa chica con papas y refresco    %i\n",num,suma); break;
		
		case 2: 
             printf("\nCantidad                       Producto                   Total\n");
             suma += num*18;
             printf("%i                           Hotdog y refresco               %i\n",num,suma); break;
		
		case 3: 
             printf("\nCantidad                       Producto                   Total\n");
             suma += num*15;
             printf("%i                            Ensalada Rusa                  %i\n",num,suma); break;
		
		default:  printf("No ingreso una opcion\n");
  
 }
 goto inicio;
  
  system("PAUSE");	
  return 0;
}
