#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float gasto,total=52.84;
  printf("Este programa calcula la cuota de luz a pagar\n\n");
  printf("Ingrese la cantidad de KWH consumidos: ");
  scanf("%f",&gasto);
  
  if(gasto<=50){
  total = total + (gasto)*(2.288);
  }
  else{
       if(gasto<=100){
       total = total + 114.40 + (gasto-50)*(2.762);
       }
       else{
       total = total + 114.40 + 138.10 + (gasto-100)*(3.042) ;
       }
  }
  printf("\nEl monto a pagar es %.3f\n",total);
  
  
  
  
  
  
  
  
  
  
  
  system("PAUSE");	
  return 0;
}
